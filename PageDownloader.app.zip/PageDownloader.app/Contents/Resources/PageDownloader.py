from gui import Gui

'''La riga sopra perchè py2app se ne frega delle variabili di ambiente'''

myGui: Gui = Gui()
myGui.run()
